#### Clash for Windows
1. 软件下载
 + [github下载地址](https://github.com/Fndroid/clash_for_windows_pkg/releases)
 + [蓝奏云下载地址]()
2. 软件安装:
   + 这个没什么好说的,记住自己安装的路径就好了,路径可以自定的
<img src="https://cdn.jsdelivr.net/gh/anliya1/MyCdn/IMG/QQ%E6%88%AA%E5%9B%BE20200820032116.png"/>

3. 软件汉化汉化
  + 汉化包下载
     +  [github下载地址](https://github.com/BoyceLig/Clash_Chinese_Patch/releases)
     +  [蓝奏云下载地址]()
  + 替换app.asar文件
     + 找到安装的Clash的目录Clash for Windows\resources\app.asar
	 + 然后替换app.asar
4. 配置Clash代理
   + 打开👉[机场]()连接,然后用邮箱注册,然后登陆
   + 找到购买订阅,选择购买的套餐,我用的轻量级季度套餐,一个月100g流量,可以同时连5台设备,一个月10块钱.<br>
   ![](https://cdn.jsdelivr.net/gh/anliya1/MyCdn/IMG/jica.png)<br>
   + 点击我的订阅--找到一键订阅--然后复制订阅地址,注意不是一键导入配置哦!<br>
   ![](https://cdn.jsdelivr.net/gh/anliya1/MyCdn/IMG/11113311.png)<br>
   + 👉[打开订阅转换平台](https://sub.hxlm.org/)<br>
   ![](https://cdn.jsdelivr.net/gh/anliya1/MyCdn/IMG/123e.png)<br>
5. 导入配置<br>
![](https://cdn.jsdelivr.net/gh/anliya1/MyCdn/IMG/qwwq.png)<br>
